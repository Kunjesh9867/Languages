//
//  LoginPageViewController.swift
//  MachoMeals
//
//  Created by Kunjesh Kantilal Ramani on 2023-11-24.
//

import UIKit

class LoginPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    } // end func
    
    
    
} // end class

