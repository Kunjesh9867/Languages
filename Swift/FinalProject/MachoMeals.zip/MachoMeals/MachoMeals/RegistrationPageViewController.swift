//
//  RegistrationPageViewController.swift
//  MachoMeals
//
//  Created by Kunjesh Kantilal Ramani on 2023-11-24.
//

import UIKit

class RegistrationPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
} // end class
